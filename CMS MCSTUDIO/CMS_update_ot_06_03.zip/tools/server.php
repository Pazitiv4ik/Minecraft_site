<?php

echo json_encode($_SERVER, JSON_PRETTY_PRINT);

?>