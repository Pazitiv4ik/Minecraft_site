<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width"/>
    @include('mailer.layouts.styles')
</head>
<body>
<table class="body-wrap">
    @include('mailer.layouts.header')
    @include('mailer.layouts.footer')
</table>
</body>
</html>