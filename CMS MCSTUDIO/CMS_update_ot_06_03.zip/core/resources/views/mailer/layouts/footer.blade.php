<tr>
    <td class="container">
        <table>
            <tr>
                <td class="content footer" align="center">
                    <p style="text-transform: uppercase !important;">
                        Отправитель:
                        <a href="#">{{ @$general->title }} - {{ @$general->description }}</a>
                    </p>
                </td>
            </tr>
        </table>
    </td>
</tr>