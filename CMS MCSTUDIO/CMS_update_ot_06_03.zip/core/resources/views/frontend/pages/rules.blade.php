@extends('frontend.layouts.master')
@section('page_title', 'Правила')
@section('body')
<h2 class="text-center">Правила проекта</h2>
<p class="text-center">Обновлено 04.01.2021</p>
<p>Правил пока нет</p>
@endsection