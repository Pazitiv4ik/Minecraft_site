<style type="text/css">
	body {
		padding: 0 !important;
	}
	.toastr {
		max-width: 100% !important;
	}
</style>