<link rel="stylesheet" href="<?php echo e(asset('assets/css/quick-website.css')); ?>" id="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.css')); ?>" id="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/skiner.css')); ?>" id="stylesheet">
<script src="<?php echo e(asset('assets/admin/js/jquery-3.2.1.min.js')); ?>"></script>
<style>
        @font-face {
        font-family: 'Roboto', sans-serif;
    }

    * {
        font-family: 'Roboto', sans-serif;
    }

</style><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/layouts/styles.blade.php ENDPATH**/ ?>