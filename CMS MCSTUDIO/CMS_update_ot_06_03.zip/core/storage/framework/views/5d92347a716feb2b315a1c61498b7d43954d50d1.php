<?php $__env->startSection('page_title', 'Новости проекта'); ?>
<?php $__env->startSection('body'); ?>
<div class="row">
	<?php if(isset($news_list['error'])): ?>
			<div class="card shadow-lg border-0" style="max-width: 100%;">
				<div class="card-body px-5 py-5 text-center text-md-left">
					<div class="row align-items-center">
						<div class="col-md-12">
							<p class="mb-0">
								Произошла ошибка при обновлении новостей. Код: <?php echo e($news_list['error']['error_code']); ?>

							</p>
						</div>
					</div>
				</div>
			</div>
	<?php else: ?>
		<?php if(isset($news_list)): ?>
			<?php $__currentLoopData = @$news_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6 animated fadeIn">
					<div class="card hover-translate-y-n3 hover-shadow-lg overflow-hidden">
						<div class="position-relative overflow-hidden">
							<a href="#" class="d-block">
								<img alt="Image placeholder" src="<?php echo e((empty(@$value['attachments'][0]['photo']['sizes'][4]['url'])) ? asset('assets').'/default.jpg' : @$value['attachments'][0]['photo']['sizes'][4]['url']); ?>" class="card-img-top">
							</a>
						</div>
						<div class="card-body py-4">
							<small class="d-block text-sm mb-2 lh-150"><?php echo e(date("d.m.Y H:i", @$value['date'])); ?></small>
							<p class="mt-3 mb-0"><?php echo e(mb_strimwidth(@$value['text'], 0, 140, "...")); ?></p>
						</div>
						<div class="card-footer border-0 delimiter-top">
							<div class="row align-items-center">
								<div class="col text-left">
									<div class="actions">
										<a href="#" class="action-item"><i class="fas fa-heart"></i> <?php echo e((!@$value['likes']['count']) ? '0' : @$value['likes']['count']); ?></a>
										<a href="#" class="action-item"><i class="fas fa-eye"></i> <?php echo e((!@$value['views']['count']) ? '0' : @$value['views']['count']); ?></a>
									</div>
								</div>
								<div class="col-auto">
									<a href="https://vk.com/public<?php echo e(@$general->vk_group_id); ?>?w=wall-<?php echo e(str_replace('-', '', @$value['owner_id']).'_'.@$value['id']); ?>" target="_blank" class="btn btn-sm btn-primary" style="">Подробнее <i class="fas fa-arrow-right"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
		<div class="card shadow-lg border-0" style="max-width: 100%;">
			<div class="card-body px-5 py-5 text-center text-md-left">
				<div class="row align-items-center">
					<div class="col-md-12">
						<p class="mb-0">
							Новостей пока нет, но Вы держитесь 😉
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
	<?php endif; ?>

</div>
<?php if(@$vk_response->type && @$vk_response->message): ?>
<script type="text/javascript">
	$(document).ready(function() {
		var vk_bind_btn = '<?php echo e(@$vk_response->hide); ?>';
		if(vk_bind_btn) {
			$('#vk_bind_btn').slideUp(100);
		}
		notify('<?php echo e(@$vk_response->message); ?>', 8000, '<?php echo e(@$vk_response->type); ?>');
	});
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master-alternate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>