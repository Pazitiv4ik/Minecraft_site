<?php $__env->startSection('page_icon', 'fa fa-cogs'); ?>
<?php $__env->startSection('page_name', 'Настройка рейтинга'); ?>
<?php $__env->startSection('body'); ?>
<div class="row">
    <?php echo $__env->make('admin.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-12">
        <div class="tile-main">
            <div class="tile tile-smot">
                <div class="tile-head">
                </div>
            </div>
            <div class="tile">
                <form method="post" action="<?php echo e(route('admin.ratingsList.save')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="tile-body">
                        <h5>Общие настройки голосования</h5>                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>Тип призов в рейтинге</b></label>
                                    <select class="form-control select-max-width font-size-for-mobile-17" id="vote_gift_type" name="vote_gift_type">
                                        <option value="1" <?php echo e((@$item->vote_gift_type == 1) ? 'selected' : '0'); ?>>Игровая валюта</option>
                                        <option value="2" <?php echo e((@$item->vote_gift_type == 2) ? 'selected' : '0'); ?>>Реальная валюта</option>
                                        
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>Кол-во валюты</b></label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e(@$item->vote_gift_count); ?>" placeholder="Кол-во призов" id="vote_gift_count" name="vote_gift_count">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <h5>Настройки MCRate</h5>
                        <h6>Ваша ссылка на обработчик: https://<?php echo e($_SERVER['SERVER_NAME']); ?>/ratings/mcrate <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="right" title="Указывается в настройках проекта в MCRate"></i></h6>     
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>McRate.Su секретный ключ</b></label>
                                    <div class="input-group">
                                        <input type="password" data-hover-view="password" class="form-control" value="<?php echo e(@$item->secret_mcrate); ?>" placeholder="Секретный ключ" id="secret_mcrate" name="secret_mcrate">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>McRate.Su ссылка для голосования</b></label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e(@$item->link_mcrate); ?>" placeholder="http://mcrate.su/project/ID" id="link_mcrate" name="link_mcrate">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h5>Настройки TopCraft</h5>   
                        <h6>Ваша ссылка на обработчик: https://<?php echo e($_SERVER['SERVER_NAME']); ?>/ratings/topcraft <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="right" title="Указывается в настройках проекта в TopCraft"></i> </h6> 
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>TopCraft.Ru секретный ключ</b></label>
                                    <div class="input-group">
                                        <input type="password" data-hover-view="password" class="form-control" value="<?php echo e(@$item->secret_topcraft); ?>" placeholder="Секретный ключ" id="secret_topcraft" name="secret_topcraft">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label"><b>TopCraft.Ru ссылка для голосования</b></label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo e(@$item->link_topcraft); ?>" placeholder="https://topcraft.ru/servers/ID/" id="link_topcraft" name="link_topcraft">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-outline-primary btn-block" type="submit">
                            <i class="fa fa-fw fa-lg fa-check-circle"></i> Сохранить
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    
    $('#vote_gift_type').on('change', function() {
        $('#vote_gift_count').val('');
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/ratingsList.blade.php ENDPATH**/ ?>