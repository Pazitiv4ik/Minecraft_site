<tr>
    <td class="container">
        <table>
            <tr>
                <td align="center" class="masthead">
                    <h1 style="color:#fff;">
                        <?php echo e(@$general->title); ?>

                    </h1>
                </td>
            </tr>
            <tr>
                <td class="content">
                    <h2>
                        Привет <?php echo e(@$user->username); ?>!
                    </h2>
                    <p>
                        <?php echo @$data_text; ?>
                    </p>
                </td>
            </tr>
        </table>
    </td>
</tr><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/mailer/layouts/header.blade.php ENDPATH**/ ?>