<?php if(session()->has('success')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
            notify("<?php echo e(session()->get('success')); ?>", 8000, "success");
        });
    </script>
<?php endif; ?>

<?php if(session()->has('alert')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
            notify("<?php echo e(session()->get('alert')); ?>", 8000, "warning");
        });
    </script>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/admin/layouts/flash.blade.php ENDPATH**/ ?>