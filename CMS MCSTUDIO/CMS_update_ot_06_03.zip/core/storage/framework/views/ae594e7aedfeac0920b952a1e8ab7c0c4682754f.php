<?php $__env->startSection('page_title', 'Восстановление пароля'); ?>
<?php $__env->startSection('body'); ?>
    <div class="alert alert-group alert-primary alert-dismissible fade show alert-icon" role="alert">
        <div class="alert-group-prepend">
            <span class="alert-group-icon text-">
                <i class="fa fa-info-circle"></i>
            </span>
        </div>
        <div class="alert-content">
            <strong style="font-weight:700;">
                Введите ваш почтовый ящик в поле ниже и получите ссылку на сброс пароля
            </strong>
        </div>
    </div>
    <form action="<?php echo e(route('forgot.pass')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-8">
                <input type="text" name="email" class="form-control form-control-sm validate input-field <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" placeholder="Введите ваш E-Mail" required>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-sm btn-primary w-100 mb-2">
                    Отправить заявку
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>