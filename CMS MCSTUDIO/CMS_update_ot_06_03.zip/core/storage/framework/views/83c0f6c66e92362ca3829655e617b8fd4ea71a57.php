<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width"/>
    <?php echo $__env->make('mailer.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<table class="body-wrap">
    <?php echo $__env->make('mailer.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('mailer.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</table>
</body>
</html><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/mailer/dashboard.blade.php ENDPATH**/ ?>