<tr>
    <td class="container">
        <table>
            <tr>
                <td class="content footer" align="center">
                    <p style="text-transform: uppercase !important;">
                        Отправитель:
                        <a href="#"><?php echo e(@$general->title); ?> - <?php echo e(@$general->description); ?></a>
                    </p>
                </td>
            </tr>
        </table>
    </td>
</tr><?php /**PATH C:\OpenServer\domains\mcstudiocms.test\core\resources\views/mailer/layouts/footer.blade.php ENDPATH**/ ?>